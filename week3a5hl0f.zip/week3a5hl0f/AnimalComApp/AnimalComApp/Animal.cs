﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalComApp
{
    class Animal
    {
        private String name;
        private int year_of_birth;
        private int beautyPoint;
        private int behaviorPoint;
        private int score;
        private static int currentYear;
        private static int ageLimit;
      

        public Animal( String name, int birthYear)
        {
            this.name = name;
            this.year_of_birth = birthYear;

        }

        public int age() {
            return currentYear - year_of_birth;
        
        }
        public void scoring( int beautyPoint, int behavoupoint) {

            this.beautyPoint = beautyPoint;
            this.behaviorPoint = behavoupoint;
            if (age() < ageLimit)
            {


                score = age() * behaviorPoint + (ageLimit - age()) * beautyPoint;
            }
            else
                score = 0;
        
        
        
        }
        public override string ToString()
        {


            return name + " has " + score + " points .";
        }

        public string Name { get { return name; } }
        public int BirthYear { get { return year_of_birth; } }
        public int BeautyPOINT { get { return beautyPoint; } }
        public int BehaviourPoint { get { return score; } }
        public static int CurrentYear { get { return currentYear; }
        set { currentYear = value; }
        }
        public int scorepoint { get { return score; } }

        public static int AgeLimit {  get { return ageLimit; }
        set { ageLimit = value; }
        }


    }
}
