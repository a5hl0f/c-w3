﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalComApp
{
    class Program
    {
        static void Main(string[] args)
        {

            int currentYear = 2021;
            int ageLimit = 10;
            Animal.CurrentYear = currentYear;
            Animal.AgeLimit = ageLimit;


            //  oneAnimalTest(currentYear, ageLimit);
            competition(currentYear, ageLimit);


        }

        private static void competition(int currentYear, int ageLimit)
        {
            Animal animal;
            string name;
            int birthYear;
            int beautyPOINT, behaviour;
            int randLimit = 10;

            Random rand = new Random();
            int numberpart = 0;
            int sumPoint = 0;
            int maxPoint = 0;

            Console.WriteLine("start");
            char cont = 'y';
            while (cont == 'y')
            {
                Console.WriteLine("animal name");
                name = Console.ReadLine();
                Console.WriteLine("BIRTHYEAR");
                while(!int.TryParse(Console.ReadLine(),out birthYear))
                {
                    Console.Write("ERROR IN YEAR PARAMETER  PLEASE TRY AGAIN");

                }
                beautyPOINT = rand.Next(randLimit + 1);
                behaviour= rand.Next(randLimit + 1);
                animal = new Animal(name, birthYear);
                animal.scoring(beautyPOINT, behaviour);
                Console.WriteLine(animal);
                numberpart++;
                sumPoint += animal.scorepoint;
                if (maxPoint < animal.scorepoint)
                {
                    maxPoint = animal.scorepoint;
                }
                Console.WriteLine(" is there any other participante ? (y/n)");
                cont = char.Parse(Console.ReadLine());
               
            }


            Console.WriteLine("\n NUMBER OF PARTICIPANTE " + numberpart + " sum of the score " + sumPoint + " maxpoint was " + maxPoint);

        }

        private static void oneAnimalTest(int currentYear, int ageLimit)
        {
            Animal animal;
            string name;
            int birthYear;
            int beautyPOINT, behaviour;
            name = "Bob";
            birthYear = 2018;
            beautyPOINT = 5;
            behaviour = 3;
            animal = new Animal(name, birthYear);
            animal.scoring(beautyPOINT, behaviour);
            Console.WriteLine(animal);
            Console.ReadKey();
        
        
        }
    }
}
